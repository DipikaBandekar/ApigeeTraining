 /*
 {
            "uuid": "75002860-a94d-11e7-b26c-0ec25ecb10a2",
            "type": "truck",
            "name": "Five Guys",
            "created": 1507153579861,
            "modified": 1507153579861,
            "location": "Napoles",
            "metadata": {
                "path": "/trucks/75002860-a94d-11e7-b26c-0ec25ecb10a2",
                "size": 360
            },
            "owner": "Pito Perez"
        }
*/

try {
    var truck = JSON.parse(context.getVariable('response.content')).entities[0];
    delete truck.uuid;
    delete truck.type;
    delete truck.created;
    delete truck.modified;
    delete truck.metadata;
    context.setVariable('response.content', JSON.stringify(truck));
} catch(e) {
    context.setVariable('JS_EXCEPTION', e);
}