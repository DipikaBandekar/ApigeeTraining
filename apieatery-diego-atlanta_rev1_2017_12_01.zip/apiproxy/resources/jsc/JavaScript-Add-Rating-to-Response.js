  /*
 {
            "uuid": "75002860-a94d-11e7-b26c-0ec25ecb10a2",
            "type": "truck",
            "name": "Five Guys",
            "created": 1507153579861,
            "modified": 1507153579861,
            "location": "Napoles",
            "metadata": {
                "path": "/trucks/75002860-a94d-11e7-b26c-0ec25ecb10a2",
                "size": 360
            },
            "owner": "Pito Perez"
        }
*/

try {
    var _truck_response = JSON.parse(context.getVariable('response.content'));
    var ratings = JSON.parse(context.getVariable('calloutResponse_ratings.content')).entities;
    ratings.forEach(function(rating) {
        Object.keys(rating).forEach(function(key) {
            delete rating.uuid;
            delete rating.type;
            delete rating.created;
            delete rating.modified;
            delete rating.metadata;
        });
    });
    _truck_response.ratings = ratings;
    context.setVariable('response.content', JSON.stringify(_truck_response));
} catch(e) {
    context.setVariable('JS_EXCEPTION', e);
}